<html>
<style>
		body {
		color: 7B5026;
		font-family: Monotype Corsiva;
		color: black;
		}

		label1 {
		font-weight: bold;
		color: #7B5026;
		font-family: Monotype Corsiva;
		font-size: large;
		}

		label2 {
		font-weight: bold;
		color: #7B5026;
		font-family: Monotype Corsiva;
		font-size: large;
		}

		label3 {
		font-weight: bold;
		color: #7B5026;
		font-family: Monotype Corsiva;
		font-size: large;
		}
</style>

<body>
<div id="data">
				<div class="row">
					<div id="me">
						<span id="pic"></span>
						<span id="name"></span><br />
						<span id="dob"></span><br />
						<span id="friends"></span>
					</div>		
				</div>
				<div class="col s12">
	    			<label1>Height</label1><br />
					<select>
						<option value="" disabled selected>Choose your option</option>
						<option value="<1.50">under 1.50m</option>
						<option value="1.51-1.60">1.51m-1.60m</option>
						<option value="1.61-1.70">1.61m-1.70m</option>
						<option value="1.71-1.80">1.71m-1.80m</option>
						<option value="1.81-1.90">1.81m-1.90m</option>
						<option value="above">above 1.90m</option>
					</select>
	    		</div>
				<div class="col s12">
	    			</br>
	    			<label2>Level</label2><br />
					<select>
						<option value="" disabled selected>Choose your option</option>
						<option value="Beginner">Beginner</option>
						<option value="Intermediate">Intermediate</option>
						<option value="Advanced">Advanced</option>
						<option value="Professional">Professional</option>
					</select>
	    		</div>
	    		<div class="col s6">
	    			</br>
	    			<label3>Dance Style</label3><br />
	    			<p>
						<input type="checkbox" id="test5" />
						<label for="test5">Rumba</label>
					</p>
					<p>
						<input type="checkbox" id="test6"  />
						<label for="test6">Cha Cha</label>
					</p>
					<p>
						<input type="checkbox" id="test7"  />
						<label for="test7">Waltz</label>
					</p>
					<p>
						<input type="checkbox" id="test7"  />
						<label for="test7">Jive</label>
					</p>
	    	</div>
			</div>
</body>
</html>