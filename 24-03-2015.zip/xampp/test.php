<? echo $_SERVER['HTTPS']; ?>
