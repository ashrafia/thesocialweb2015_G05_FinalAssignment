<html>
<head>
<title>XAMPP webalizer</title>
<link href="xampp.css" rel="stylesheet" type="text/css">
</head>

<body>
&nbsp;<p>
<pre>
<?
	system("/Applications/XAMPP/xamppfiles/bin/webalizer;sleep 2");
?>
<script>
	document.location="/webalizer/";
</script>
</pre>
</body>
</html>
